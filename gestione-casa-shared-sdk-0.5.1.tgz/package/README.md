# Gestione Casa – Shared SDK

Pacchetto TypeScript condiviso tra **Gestione Casa OCR**, **Gestione Casa License Manager** e i futuri client Android, iOS, Windows e macOS.

## Obiettivi della versione 0.5.0

La versione 0.5.0 introduce i contratti condivisi di attivazione, licenza V2 e receipt di validazione:

1. **Licensing V2 & Offline Policy**: Supporto `LicenseDocumentV2` con `OfflinePolicyV2` e accoppiamento rigido di versione (1:1 per schema e firma).
2. **Validation Receipts**: Contratti `ValidationReceiptV1` e `SignedValidationReceiptV1` con verifica di binding crittografico tra licenza V2 e scontrino di validazione.
3. **Browser-Safe Pure TS SHA-256**: Calcolo SHA-256 sincrono e deterministico in TypeScript puro senza dipendenze `node:crypto` o `Buffer`.
4. **Dispatcher Canonico Rigido**: `buildCanonicalLicensePayload` con gestione esplicita delle versioni di schema (1 / V1, 2 / V2, rifiuto esplicito di versioni sconosciute o ambigue).
5. **Envelope di Attivazione e Scambio**: Contratti di envelope per `contact-requests` e `activation`.

Lo SDK **non contiene** React, Dexie, IndexedDB, UI, API server, invio email o logica specifica di una singola piattaforma. Definisce esclusivamente i contratti e le funzioni pure di validazione e scambio.

## Struttura

```text
src/
  common/
    types.ts
    utils.ts
    index.ts
  licensing/
    constants.ts
    types.ts
    LicenseValidator.ts
    LicenseEngine.ts
    lifecycle.ts
    adapters.ts
    serialization.ts
    index.ts
  customers/
    types.ts
    CustomerValidator.ts
    adapters.ts
    index.ts
  contact-requests/
    types.ts
    ContactRequestValidator.ts
    exchange.types.ts
    exchange.ts
    index.ts
  activation/
    types.ts
    validators.ts
    canonical.ts
    envelopes.ts
    serialization.ts
    index.ts
```

## Comandi

```bash
npm install
npm run typecheck
npm test
npm run build
npm run pack:check
```

## Uso

```ts
import {
  LicenseEngine,
  LicenseValidator,
  evaluateLicense,
} from '@gestione-casa/shared-sdk/licensing';

import {
  CustomerValidator,
  managerCustomerEntityToDocument,
} from '@gestione-casa/shared-sdk/customers';

import {
  ContactRequestValidator,
} from '@gestione-casa/shared-sdk/contact-requests';

// Validazione Cliente
const customerResult = CustomerValidator.validate(rawCustomer);

// Validazione Richiesta
const requestResult = ContactRequestValidator.validate(rawRequest);
```

## Relazioni tra Modelli

- **`LicenseDocument.customerId`**: Collegamento canonico ufficiale tra licenza e cliente.
- **`ContactRequest.linkedCustomerId`**: Registra l'eventuale conversione di una richiesta di contatto in cliente.
- **`ContactRequest.linkedLicenseId`**: Registra l'eventuale licenza associata (richiede la presenza di `linkedCustomerId`).

Note di roadmap:
- L'integrazione concreta nelle app avverrà nella **Fase 2.3**.
- Il workflow operativo automatizzato Richiesta → Cliente → Licenza appartiene alla **Fase 2.4**.

## Confine di sicurezza

Il checksum rileva errori di digitazione o alterazioni accidentali, ma **non costituisce una firma crittografica**. Prima della distribuzione commerciale occorrerà firmare il payload nel License Manager e verificarlo nei client tramite chiave pubblica Ed25519.

## Documentazione

Consultare:

- `docs/ARCHITECTURE.md`
- `docs/PHASE_2_2_SHARED_MODELS.md`
- `docs/PHASE_2_3_CONTACT_REQUEST_EXCHANGE.md`
- `docs/INTEGRATION_LICENSE_MANAGER.md`
- `docs/INTEGRATION_OCR.md`
- `docs/MIGRATION_MATRIX.md`
- `docs/SOURCE_COMPARISON.md`

